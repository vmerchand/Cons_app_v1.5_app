function initData() {
  jimData.variables["flag1"] = "cero";
  jimData.datamasters["CentroJusticia"] = [
    {
      "id": 1,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "CentroJusticia",
      "userdata": {
        "Estado": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}