(function(window, undefined) {

  var jimLinks = {
    "d79fe8d9-c249-43a9-8cc3-a475bf430f15" : {
      "btnOk" : [
        "e59cafce-2294-4653-ac36-2651a7082c2c"
      ]
    },
    "18ad1943-6595-4efd-ab76-7db5b6ae047b" : {
      "btnGuardarSalir" : [
        "d79fe8d9-c249-43a9-8cc3-a475bf430f15"
      ],
      "btnGuardarEnviarSalir" : [
        "96d8b75c-9af2-411a-860c-f983eab0380f"
      ],
      "btnGuardarSalir_1" : [
        "d8a8bd87-f138-46eb-b1cd-e214c349a8f1"
      ]
    },
    "b9b09868-35ab-4da4-8368-f644f11d3ca1" : {
      "imgSi" : [
        "d8a8bd87-f138-46eb-b1cd-e214c349a8f1"
      ]
    },
    "58d885fe-5251-4c5c-8c98-a4b27863871e" : {
      "block_guias" : [
        "82a02069-7dee-416f-bf41-6a016dbbadb9"
      ],
      "block_infraestructura" : [
        "2ed531ac-a968-4769-9bb5-0bb943e08acb"
      ],
      "block_audiencias" : [
        "e59cafce-2294-4653-ac36-2651a7082c2c"
      ]
    },
    "d8a8bd87-f138-46eb-b1cd-e214c349a8f1" : {
      "btnExit" : [
        "18ad1943-6595-4efd-ab76-7db5b6ae047b"
      ]
    },
    "96d8b75c-9af2-411a-860c-f983eab0380f" : {
      "Rectangle_1" : [
        "d8a8bd87-f138-46eb-b1cd-e214c349a8f1"
      ]
    },
    "2ed531ac-a968-4769-9bb5-0bb943e08acb" : {
      "btnContinuar" : [
        "9f38956c-7fbe-444d-a235-9741a38d3303"
      ]
    },
    "60aad723-6685-4a01-92ee-b631ea06be97" : {
      "btnPhoto" : [
        "9f38956c-7fbe-444d-a235-9741a38d3303"
      ]
    },
    "40460924-2152-4147-b90e-cdd470103834" : {
      "btnSeleccionar" : [
        "9f38956c-7fbe-444d-a235-9741a38d3303"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_1" : [
        "58d885fe-5251-4c5c-8c98-a4b27863871e"
      ]
    },
    "82a02069-7dee-416f-bf41-6a016dbbadb9" : {
      "block_audiencias" : [
        "94f802ff-0c78-4275-baac-70ff16a3eeb0"
      ],
      "guia" : [
        "58d885fe-5251-4c5c-8c98-a4b27863871e"
      ]
    },
    "94f802ff-0c78-4275-baac-70ff16a3eeb0" : {
      "guia" : [
        "82a02069-7dee-416f-bf41-6a016dbbadb9"
      ]
    },
    "e59cafce-2294-4653-ac36-2651a7082c2c" : {
      "btnInicial" : [
        "b9b09868-35ab-4da4-8368-f644f11d3ca1"
      ]
    },
    "53c69bf5-cecd-4d1d-8883-c8a717845ebb" : {
      "btnStop" : [
        "9f38956c-7fbe-444d-a235-9741a38d3303"
      ]
    },
    "9f38956c-7fbe-444d-a235-9741a38d3303" : {
      "btnAudio1" : [
        "53c69bf5-cecd-4d1d-8883-c8a717845ebb"
      ],
      "btnFoto1" : [
        "60aad723-6685-4a01-92ee-b631ea06be97"
      ],
      "btnGaleria1" : [
        "40460924-2152-4147-b90e-cdd470103834"
      ]
    },
    "917cc990-4cfa-416f-ba09-e868f750ab9e" : {
      "rec_home" : [
        "58d885fe-5251-4c5c-8c98-a4b27863871e"
      ]
    },
    "6fe6502b-1dd0-4961-9e15-6a18aaa7b10f" : {
      "rec_home" : [
        "58d885fe-5251-4c5c-8c98-a4b27863871e"
      ]
    },
    "1fe74c68-f646-4e8a-9387-700c7217ddfe" : {
      "rec_home" : [
        "58d885fe-5251-4c5c-8c98-a4b27863871e"
      ]
    },
    "403340a5-bec8-413f-921e-8398dab3c084" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);